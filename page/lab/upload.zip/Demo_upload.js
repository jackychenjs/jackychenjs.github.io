$("#uploadify").uploadify({
    height: 30,
    width: 120,
    swf: 'uploadify/upload.swf',
    uploader: 'http://upd.pinganfang.dev.ipo.com/upload/secret.html',
    successTimeout: 300
});